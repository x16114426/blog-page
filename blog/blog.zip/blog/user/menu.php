<h1>Blog</h1>
<ul id='adminmenu'>
	
	<li><a href="../" target="_blank">View All Blogs</a></li>
	<li><a href='logout.php'>Logout</a></li>
</ul>
<div class='clear'></div>
<hr />